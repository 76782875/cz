<?php
echo js::alert('pre install');
