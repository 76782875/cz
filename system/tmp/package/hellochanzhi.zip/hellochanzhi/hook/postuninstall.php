<?php
echo js::alert('post uninstall');
