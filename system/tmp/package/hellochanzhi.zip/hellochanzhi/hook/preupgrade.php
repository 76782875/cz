<?php
echo js::alert('pre upgrade from ' . $this->post->installedVersion . 'to' . $this->post->upgradeVersion);
