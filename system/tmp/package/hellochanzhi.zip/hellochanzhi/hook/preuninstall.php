<?php
echo js::alert('pre uninstall');
