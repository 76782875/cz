<?php
echo js::alert('post upgrade from ' . $this->post->installedVersion . 'to' . $this->post->upgradeVersion);
